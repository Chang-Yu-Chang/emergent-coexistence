rm(list=ls())
library(ggplot2)
library(data.table)
library(ggpubr)
library(viridis)
library(tidyverse)
jv_data = fread('../Data/20GC_Data.csv')
jv_data = jv_data[jv_data$CS=='D-Glucose']
isolates = fread('../Data/isolates.csv')
isolates$IsolateID = paste(isolates$Community,isolates$Isolate,sep='_')
pairs = fread('../Data/pairs.csv')
pairs$Isolate1ID = paste(pairs$Community,pairs$Isolate1,sep='_')
pairs$Isolate2ID = paste(pairs$Community,pairs$Isolate2,sep='_')
pairs$SangerID1 =isolates$SangerID[match(pairs$Isolate1ID,isolates$IsolateID)]
pairs$SangerID2 =isolates$SangerID[match(pairs$Isolate2ID,isolates$IsolateID)]
coms = unique(isolates$Community)

for(i in coms){
  com_isol = isolates[Community==i]
  pairs_isol = pairs[Community==i]
  strains = unique(com_isol$SangerID)
  nisol = length(strains)
  pairs_matrix = matrix(nrow =nisol,ncol=nisol)
  colnames(pairs_matrix) = strains
  rownames(pairs_matrix) = strains
  for(j in 1:ncol(pairs_matrix)){
    for(k in 1:nrow(pairs_matrix)){
      pair_temp_a = pairs_isol[SangerID1==strains[j] &SangerID2==strains[k]]
      pair_temp_b = pairs_isol[SangerID1==strains[k] &SangerID2==strains[j]]
      if(nrow(pair_temp_a) ==0 & nrow(pair_temp_b)==0){
        pairs_matrix[j,k] <-'NA'
      }
      if(nrow(pair_temp_a) ==1 & nrow(pair_temp_b)==0){
        if(pair_temp_a$InteractionType =='exclusion' & pair_temp_a$Isolate1==pair_temp_a$From){
          pairs_matrix[j,k] <- 'Win'
        }
        if(pair_temp_a$InteractionType =='exclusion' & pair_temp_a$Isolate1==pair_temp_a$To){
          pairs_matrix[j,k] <- 'Loss'
        }
        if(pair_temp_a$InteractionType !='exclusion'){
          pairs_matrix[j,k] <- 'Draw'
        }      
      }
      if(nrow(pair_temp_a) ==0 & nrow(pair_temp_b)==1){
        if(pair_temp_b$InteractionType =='exclusion' & pair_temp_b$Isolate1==pair_temp_b$From){
          pairs_matrix[j,k] <- 'Loss'
        }
        if(pair_temp_b$InteractionType =='exclusion' & pair_temp_b$Isolate1==pair_temp_b$To){
          pairs_matrix[j,k] <- 'Win'
        }
        if(pair_temp_b$InteractionType !='exclusion'){
          pairs_matrix[j,k] <- 'Draw'
        }
      }
    }
  }
  pair_df =melt(pairs_matrix)
jv_data$Function = 'Respirer'
jv_data[jv_data$Family %in% c('Enterobacteriaceae','Aeromonadaceae'),]$Function = 'Fermenter'
print(com_isol[order(com_isol$Rank)])
safe_colorblind_palette <- c("#88CCEE", "#CC6677", "#DDCC77", "#117733", "#332288", "#AA4499", 
                             "#44AA99", "#999933", "#882255", "#661100", "#6699CC", "#888888")


p1 <-ggplot(jv_data[jv_data$SangerID %in% com_isol$SangerID],
            aes(x=Time,y=OD620,col=as.factor(SangerID),shape=Function)) +
  geom_point(size=1,stroke=1) +scale_colour_manual(values = safe_colorblind_palette) +
  scale_shape_manual(values=c(1,2), guide = "none")+
  labs(x='Time',y='OD620',col='Strain') + theme_classic()
pair_df$value = factor(pair_df$value,levels=c('Win','Loss','Draw','NA'))
p2 <- ggplot(pair_df) +
  geom_tile(aes(x = as.factor(Var1), y = as.factor(Var2), fill = value), width = 0.9, height = 0.9) +
  theme_classic() + labs(x='',y='') +theme(legend.position = 'none',axis.text.x = element_text(angle=90)) +
  scale_fill_manual(values=c('Blue','Red','Purple','Black'))
p3 = p1 +annotation_custom(ggplotGrob(p2),xmin=-4,xmax=12,ymin=0.4,ymax=0.6)
ggsave(paste('../Plots/',com_isol$Community[1],'.png',sep=''),p3)
}